
<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>MediaWiki talk:Gadget-HotCat.js - Wikimedia Commons</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":!1,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"fc3a8ad4-d74b-44fe-82d8-ed8a9514777c","wgCSPNonce":!1,"wgCanonicalNamespace":"MediaWiki_talk","wgCanonicalSpecialPageName":!1,"wgNamespaceNumber":9,"wgPageName":"MediaWiki_talk:Gadget-HotCat.js","wgTitle":"Gadget-HotCat.js","wgCurRevisionId":419222543,"wgRevisionId":419222543,"wgArticleId":3190584,"wgIsArticle":!0,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":["Gadget scripts"],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"MediaWiki_talk:Gadget-HotCat.js","wgRelevantArticleId":3190584,"wgIsProbablyEditable":!0,"wgRelevantPageIsProbablyEditable":!0,"wgRestrictionEdit":[],
"wgRestrictionMove":[],"wgMediaViewerOnClick":!0,"wgMediaViewerEnabledByDefault":!1,"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":!0,"nearby":!0,"watchlist":!0,"tagline":!0},"wgWMESchemaEditAttemptStepOversample":!1,"wgULSCurrentAutonym":"English","wgNoticeProject":"commons","wbUserSpecifiedLanguages":[],"wgCentralAuthMobileDomain":!1,"wgEditSubmitButtonLabelPublish":!0,"wbmiDefaultProperties":["P180"],"wbmiPropertyTitles":{"P180":"Items portrayed in this file"},"wbmiPropertyTypes":{"P180":"wikibase-item"},"wbmiSearchTitles":{"P180":"files depicting…"},"wbmiHelpUrls":{"P180":"https://commons.wikimedia.org/wiki/Special:MyLanguage/Commons:Depicts"},"wbmiExternalEntitySearchBaseUri":"https://www.wikidata.org/w/api.php","wbmiMediaInfoEnableSearch":!1,"wbmiRepoApiUrl":"/w/api.php","wbmiSupportedDataTypes":["wikibase-item","string","quantity","time","monolingualtext",
"external-id","globe-coordinate","url"]};RLSTATE={"ext.gadget.Long-Image-Names-in-Categories":"ready","ext.globalCssJs.user.styles":"ready","site.styles":"ready","noscript":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","user":"ready","user.options":"loading","ext.inputBox.styles":"ready","mediawiki.ui.input":"ready","mediawiki.ui.checkbox":"ready","mediawiki.ui.button":"ready","mediawiki.toc.styles":"ready","skins.vector.styles.legacy":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.uls.pt":"ready","ext.wikimediaBadges":"ready"};RLPAGEMODULES=["site","mediawiki.page.startup","mediawiki.page.ready","mediawiki.toc","skins.vector.legacy.js","ext.gadget.Slideshow","ext.gadget.ZoomViewer","ext.gadget.CollapsibleTemplates","ext.gadget.fastcci","ext.gadget.Stockphoto","ext.gadget.WatchlistNotice","ext.gadget.AjaxQuickDelete","ext.gadget.WikiMiniAtlas","ext.gadget.LanguageSelect","ext.centralauth.centralautologin","mmv.head","mmv.bootstrap.autostart",
"ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging","ext.wikimediaEvents","ext.wikimediaEvents.wikibase","ext.navigationTiming","ext.uls.compactlinks","ext.uls.interface","wikibase.mediainfo.search","ext.centralNotice.geoIP","ext.centralNotice.startUp"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@1hzgi",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.inputBox.styles%7Cext.uls.pt%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediaBadges%7Cmediawiki.toc.styles%7Cmediawiki.ui.button%2Ccheckbox%2Cinput%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.Long-Image-Names-in-Categories&amp;only=styles&amp;skin=vector"/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.35.0-wmf.35"/>
<meta name="referrer" content="origin"/>
<meta name="referrer" content="origin-when-crossorigin"/>
<meta name="referrer" content="origin-when-cross-origin"/>
<link rel="alternate" type="application/x-wiki" title="Edit" href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit"/>
<link rel="edit" title="Edit" href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit"/>
<link rel="apple-touch-icon" href="/static/apple-touch/commons.png"/>
<link rel="shortcut icon" href="/static/favicon/commons.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikimedia Commons"/>
<link rel="EditURI" type="application/rsd+xml" href="//commons.wikimedia.org/w/api.php?action=rsd"/>
<link rel="license" href="//creativecommons.org/licenses/by-sa/3.0/"/>
<link rel="alternate" type="application/atom+xml" title="Wikimedia Commons Atom feed" href="/w/index.php?title=Special:RecentChanges&amp;feed=atom"/>
<link rel="canonical" href="https://commons.wikimedia.org/wiki/MediaWiki_talk:Gadget-HotCat.js"/>
<link rel="dns-prefetch" href="//login.wikimedia.org"/>
<link rel="dns-prefetch" href="//meta.wikimedia.org" />
<!--[if lt IE 9]><script src="/w/resources/lib/html5shiv/html5shiv.js"></script><![endif]-->
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-9 ns-talk mw-editable page-MediaWiki_talk_Gadget-HotCat_js rootpage-MediaWiki_talk_Gadget-HotCat_js skin-vector action-view skin-vector-legacy">
<div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
		<div id="siteNotice" class="mw-body-content"><!-- CentralNotice --></div>
	<div class="mw-indicators mw-body-content">
</div>

	<h1 id="firstHeading" class="firstHeading" lang="en">MediaWiki talk:Gadget-HotCat.js</h1>
	
	<div id="bodyContent" class="mw-body-content">
		<div id="siteSub" class="noprint">From Wikimedia Commons, the free media repository</div>
		<div id="contentSub"></div>
		
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#p-search">Jump to search</a>
		<div id="mw-content-text" lang="en" dir="ltr" class="mw-content-ltr"><div class="mw-parser-output"><table class="plainlinks tmbox messagebox layouttemplate tmbox-notice" style="margin:1px 10%">
<tbody><tr>
<td class="mbox-image">
  <img alt="" src="https://upload.wikimedia.org/wikipedia/commons/c/c8/Ambox_notice.png" decoding="async" width="40" height="40" data-file-width="40" data-file-height="40" /></td>
<td class="mbox-text" style=""> This script, <i><b>HotCat</b></i>, is a JavaScript <a href="/wiki/Special:Preferences#mw-prefsection-gadgets" title="Special:Preferences">gadget</a> which can be enabled or disabled in <a href="/wiki/Special:Preferences#mw-prefsection-gadgets" title="Special:Preferences">your Preferences</a>.&#160;The documentation page is located at <b><a href="/wiki/Help:Gadget-HotCat" title="Help:Gadget-HotCat">Help:Gadget-HotCat</a></b>. </td>
</tr>
</tbody></table><table class="plainlinks tmbox messagebox layouttemplate tmbox-notice" style="margin:1px 10%">
<tbody><tr>
<td class="mbox-image">
  <a href="/wiki/File:Farm-Fresh_tag_blue_edit.png" class="image"><img alt="Farm-Fresh tag blue edit.png" src="https://upload.wikimedia.org/wikipedia/commons/d/d0/Farm-Fresh_tag_blue_edit.png" decoding="async" width="34" height="34" data-file-width="32" data-file-height="32" /></a></td>
<td class="mbox-text" style=""> <div style="margin-top:2px; padding:.4em 1em .5em; border:1px solid #d4cfa4; background:#fff9db;">Gadget descriptions: <span style="font-size:x-small;line-height:140%" class="plainlinks noprint"><a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/bg">Български</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/bn">বাংলা</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/ca">Català</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/de">Deutsch</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/es">Español</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/fa">فارسی</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/fi">Suomi</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/fr">Français</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/hr">Hrvatski</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/hu">Magyar</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/it">Italiano</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/ja">日本語</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/kk">Қазақша</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/kk-cyrl">Қазақша (кирил)‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/ko">한국어</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/mk">Македонски</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/ml">മലയാളം</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/nl">Nederlands</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/pl">Polski</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/pt">Português</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/ru">Русский</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/sl">Slovenščina</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/sv">Svenska</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat/uk">Українська</a>&#160;| <small class="plainlinks"><a class="external text" href="https://commons.wikimedia.org/w/index.php?title=MediaWiki:Gadget-HotCat/lang/lang&amp;action=edit">+/−</a></small>
</span> <small></small><br /><i>HotCat</i>:&#160;<sup><abbr title="default gadget – enabled by default">d</abbr></sup>&#32;Easily add / remove / change a category on a page, with name suggestions. <small>&#91;<a href="/wiki/Help:Gadget-HotCat" title="Help:Gadget-HotCat">documentation</a>&#160;/&#160;<a href="/wiki/File:HotCat.png" title="File:HotCat.png">example</a>&#160;/&#160;<a class="mw-selflink selflink">talk</a>&#93;</small>&#160;</div> </td>
</tr>
</tbody></table><table class="plainlinks tmbox messagebox layouttemplate tmbox-notice" style="">
<tbody><tr>
<td class="mbox-image">
  <div style="font-family:monospace;font-weight:bold;font-size:big;height:34px;width:34px;padding-top:15px;"><abbr title="Internationalization">i18n</abbr></div></td>
<td class="mbox-text" style=""> <div style="margin-top:2px; padding:.4em 1em .5em; border:1px solid #d4cfa4; background:#fff9db;">Gadget translations: 
<p><span style="font-size:x-small;line-height:140%" class="plainlinks noprint"><a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/als">Alemannisch</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ar">العربية</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/arc">ܐܪܡܝܐ</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/az">Azərbaycanca</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/be">Беларуская</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/be-tarask">Беларуская (тарашкевіца)‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/bjn">Bahasa Banjar</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/bn">বাংলা</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ca">Català</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ce">Нохчийн</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/cs">Čeština</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/da">Dansk</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/de">Deutsch</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/de-formal">Deutsch (Sie-Form)‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/dsb">Dolnoserbski</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/el">Ελληνικά</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/en">English</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/eo">Esperanto</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/es">Español</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/et">Eesti</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/fa">فارسی</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/fi">Suomi</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/fr">Français</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/frr">Nordfriisk</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/gl">Galego</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/he">עברית</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/hr">Hrvatski</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/hsb">Hornjoserbsce</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/hu">Magyar</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/hy">Հայերեն</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/id">Bahasa Indonesia</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ilo">Ilokano</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/it">Italiano</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ja">日本語</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ka">ქართული</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/kk">Қазақша</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/kk-cyrl">Қазақша (кирил)‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ko">한국어</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ku">Kurdî</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/lt">Lietuvių</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/lv">Latviešu</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/min">Baso Minangkabau</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ml">മലയാളം</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ms">Bahasa Melayu</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/nl">Nederlands</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/nn">Norsk nynorsk</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/no">Norsk bokmål</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/pl">Polski</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/pt">Português</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/pt-br">Português do Brasil</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ro">Română</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ru">Русский</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/si">සිංහල</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sk">Slovenčina</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sl">Slovenščina</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sq">Shqip</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sr">Српски / srpski</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sv">Svenska</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/szl">Ślůnski</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/te">తెలుగు</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/tr">Türkçe</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/tt">Татарча/tatarça</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/uk">Українська</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ur">اردو</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh">中文</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-cn">中文（中国大陆）‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-hans">中文（简体）‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-hant">中文（繁體）‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-hk">中文（香港）‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-mo">中文（澳門）‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-my">中文（马来西亚）‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-sg">中文（新加坡）‎</a>&#160;| <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-tw">中文（台灣）‎</a>&#160;| <small class="plainlinks"><a class="external text" href="https://commons.wikimedia.org/w/index.php?title=MediaWiki:Gadget-HotCat.js/lang/lang&amp;action=edit">+/−</a></small>
</span>&#160;
</p>
</div> </td>
</tr>
</tbody></table>
<p><br />

</p>
<table id="archivebox" role="presentation" class="tmbox tmbox-notice mbox-small" style="padding-top:4px; text-align: center;">
<tbody><tr><th><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Replacement_filing_cabinet.svg/40px-Replacement_filing_cabinet.svg.png" decoding="async" width="40" height="40" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Replacement_filing_cabinet.svg/60px-Replacement_filing_cabinet.svg.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Replacement_filing_cabinet.svg/80px-Replacement_filing_cabinet.svg.png 2x" data-file-width="200" data-file-height="200" /><br /><a href="/wiki/Special:MyLanguage/Commons:Talk_page_guidelines#Archiving" title="Special:MyLanguage/Commons:Talk page guidelines">
</a><p><a href="/wiki/Special:MyLanguage/Commons:Talk_page_guidelines#Archiving" title="Special:MyLanguage/Commons:Talk page guidelines">Archives</a>
</p>
</th></tr>
<tr><td style="text-align:left;">
<ul><li><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive01" title="MediaWiki talk:Gadget-HotCat.js/Archive01">Archive 1</a></li>
<li><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive02" title="MediaWiki talk:Gadget-HotCat.js/Archive02">Archive 2</a></li>
<li><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive03" title="MediaWiki talk:Gadget-HotCat.js/Archive03">Archive 3</a></li>
<li><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive04" title="MediaWiki talk:Gadget-HotCat.js/Archive04">Archive 4</a></li></ul>
</td></tr><tr><td><div class="mw-inputbox-centered" style=""><form name="searchbox" class="searchbox" action="/wiki/Special:Search"><input class="searchboxInput mw-ui-input mw-ui-input-inline" name="search" type="text" value="" placeholder="" size="22" dir="ltr" /><input type="hidden" value="MediaWiki talk:Gadget-HotCat.js/" name="prefix" /> <input type="submit" name="fulltext" class="mw-ui-button" value="Search" /><input type="hidden" value="Search" name="fulltext" /></form></div>
</td></tr><tr><td>Threads older than 180 days&#160;days may be archived.</td></tr>
</tbody></table>
<div id="toc" class="toc" role="navigation" aria-labelledby="mw-toc-heading"><input type="checkbox" role="button" id="toctogglecheckbox" class="toctogglecheckbox" style="display:none" /><div class="toctitle" lang="en" dir="ltr"><h2 id="mw-toc-heading">Contents</h2><span class="toctogglespan"><label class="toctogglelabel" for="toctogglecheckbox"></label></span></div>
<ul>
<li class="toclevel-1 tocsection-1"><a href="#Importing_HotCat_from_Commons"><span class="tocnumber">1</span> <span class="toctext">Importing HotCat from Commons</span></a></li>
<li class="toclevel-1 tocsection-2"><a href="#Hotcat_removing_added_categories"><span class="tocnumber">2</span> <span class="toctext">Hotcat removing added categories</span></a></li>
<li class="toclevel-1 tocsection-3"><a href="#Making_HotCat.js_compatible_with_new_skin,_Timeless"><span class="tocnumber">3</span> <span class="toctext">Making HotCat.js compatible with new skin, Timeless</span></a></li>
</ul>
</div>

<h2><span class="mw-headline" id="Importing_HotCat_from_Commons">Importing HotCat from Commons</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=1" title="Edit section: Importing HotCat from Commons">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
<p>I tried to import HotCat to wiki.openstreetmap.org using Windows and Ubuntu with Firefox. After saving, the page ends right before the second letter of the Unicode string "ℳ𝒲♥𝓊𝓃𝒾𝒸ℴ𝒹ℯ" and I do not get any indicator why the rest of the page is missing. This appears on JavaScript pages only. I tested copying HotCat to my Common.js in WM Commons and it worked here. I already confirmed that I did not trigger an AbuseFilter on wiki.openstreetmap.org. 
</p><p>Any idea what could cause that? <a href="/w/index.php?title=User:FellTiger&amp;action=edit&amp;redlink=1" class="new" title="User:FellTiger (page does not exist)">FellTiger</a> (<a href="/wiki/User_talk:FellTiger" title="User talk:FellTiger"><span class="signature-talk">talk</span></a>) 22:17, 21 February 2020 (UTC)
</p>
<dl><dd>@<a href="/w/index.php?title=User:FellTiger&amp;action=edit&amp;redlink=1" class="new" title="User:FellTiger (page does not exist)">FellTiger</a>: The Unicode character "𝒲" is outside of the <a href="https://en.wikipedia.org/wiki/Basic_Multilingual_Plane" class="extiw" title="w:Basic Multilingual Plane">w:Basic Multilingual Plane</a> (BMP; in other words, it's an "astral character"). Looks like your wiki's MySQL database was incorrectly set up to use the <code>utf8</code> charset, which can't store astral characters, rather than <code>utf8mb4</code>, which can.</dd>
<dd>You can try replacing <code>"ℳ𝒲♥𝓊𝓃𝒾𝒸ℴ𝒹ℯ"</code> with <code>"\u2133\ud835\udcb2\u2665\ud835\udcca\ud835\udcc3\ud835\udcbe\ud835\udcb8\u2134\ud835\udcb9\u212f"</code> to get around this. But you will run into the same issue with many other characters, particularly emoji; for example, if anyone tries to add 💩 to any page on your wiki, that page will be cut off at that spot. Here's an article that describes the database problem and how to fix it: <a rel="nofollow" class="external free" href="https://mathiasbynens.be/notes/mysql-utf8mb4">https://mathiasbynens.be/notes/mysql-utf8mb4</a> <a href="/wiki/User:Matma_Rex" title="User:Matma Rex">Matma Rex</a> (<a href="/wiki/User_talk:Matma_Rex" title="User talk:Matma Rex"><span class="signature-talk">talk</span></a>) 22:42, 21 February 2020 (UTC)</dd></dl>
<h2><span class="mw-headline" id="Hotcat_removing_added_categories">Hotcat removing added categories</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=2" title="Edit section: Hotcat removing added categories">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
<div class="floatright"><a href="/wiki/File:HotCat_error_for_redirected_category.jpg" class="image"><img alt="HotCat error for redirected category.jpg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/HotCat_error_for_redirected_category.jpg/400px-HotCat_error_for_redirected_category.jpg" decoding="async" width="400" height="419" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/HotCat_error_for_redirected_category.jpg/600px-HotCat_error_for_redirected_category.jpg 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/HotCat_error_for_redirected_category.jpg/800px-HotCat_error_for_redirected_category.jpg 2x" data-file-width="1750" data-file-height="1835" /></a></div>
<p>Hi, I hope this is the right location to report this. When using HotCat and adding a category with a redirect, it overwrites the first category added with HotCat. In the edit summary it retains the correct category? Edited to add that I use Brave and Chrome and it only seems to happen if the added categories are not separately confirmed before clicking "save". -- <a href="/wiki/User:Deadstar" title="User:Deadstar">Deadstar</a> (<a href="/wiki/User_talk:Deadstar" title="User talk:Deadstar">msg</a>) 10:40, 10 March 2020 (UTC)
</p>
<h2><span id="Making_HotCat.js_compatible_with_new_skin.2C_Timeless"></span><span class="mw-headline" id="Making_HotCat.js_compatible_with_new_skin,_Timeless">Making HotCat.js compatible with new skin, Timeless</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=3" title="Edit section: Making HotCat.js compatible with new skin, Timeless">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
<p>Hi, 
</p><p>I've been using HotCat a lot, on Commons and other projects. I recently switched to Timeless skin, for readability purpose... but HotCat does not work anymore in this skin.
</p><p>Is it possible to adapt it to Timeless skin, please&#160;? --<a href="/wiki/User:Hsarrazin" title="User:Hsarrazin">Hsarrazin</a> (<a href="/wiki/User_talk:Hsarrazin" title="User talk:Hsarrazin"><span class="signature-talk">talk</span></a>) 10:54, 9 April 2020 (UTC)
</p>
<dl><dd><img alt="Symbol support vote.svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Symbol_support_vote.svg/15px-Symbol_support_vote.svg.png" decoding="async" width="15" height="15" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Symbol_support_vote.svg/23px-Symbol_support_vote.svg.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Symbol_support_vote.svg/30px-Symbol_support_vote.svg.png 2x" data-file-width="180" data-file-height="185" />&#160;<b><bdi>Support</bdi></b> - I did not even actively switch to Timeless ... seems it's the new default skin, isn't it? --<a href="/wiki/User:Dealerofsalvation" title="User:Dealerofsalvation">dealer</a>of<a href="/wiki/User_talk:Dealerofsalvation" title="User talk:Dealerofsalvation">salvation</a> 17:19, 13 May 2020 (UTC)
<dl><dd>No, it isn’t the default skin; the default is still the good old Vector. Timeless is in fact quite difficult to support, especially when working with categories—category links have three different places depending on the screen resolution (on the botttom on narrow screens, on the left on medium screens and on the right on wide screens), so one has to insert CatScan’s link in all these places and synchronize between them. Not impossible, but neither a trivial change. —<a href="/wiki/User:Tacsipacsi" title="User:Tacsipacsi">Tacsipacsi</a> (<a href="/wiki/User_talk:Tacsipacsi" title="User talk:Tacsipacsi"><span class="signature-talk">talk</span></a>) 01:03, 15 May 2020 (UTC)</dd></dl></dd></dl>
<!-- 
NewPP limit report
Parsed by mw1335
Cached time: 20200515010358
Cache expiry: 2592000
Dynamic content: false
Complications: []
CPU time usage: 0.120 seconds
Real time usage: 0.187 seconds
Preprocessor visited node count: 855/1000000
Post‐expand include size: 71578/2097152 bytes
Template argument size: 20501/2097152 bytes
Highest expansion depth: 20/40
Expensive parser function count: 3/500
Unstrip recursion depth: 0/20
Unstrip post‐expand size: 464/5000000 bytes
Number of Wikibase entities loaded: 0/400
Lua time usage: 0.007/10.000 seconds
Lua memory usage: 635 KB/50 MB
-->
<!--
Transclusion expansion time report (%,ms,calls,template)
100.00%  129.442      1 -total
 50.49%   65.356      1 Template:Gadget-talk
 47.31%   61.242      3 Template:Tmbox
 44.76%   57.938      3 Template:Tmbox/core
 28.93%   37.452      1 Template:Archives
 19.11%   24.738      1 Template:Autotranslate
 18.30%   23.687      2 Template:Lang_links
 12.27%   15.886      1 Template:Support
 12.26%   15.866      1 Template:Gadget-desc
 10.35%   13.398      1 MediaWiki:Gadget-HotCat.js/lang
-->

<!-- Saved in parser cache with key commonswiki:pcache:idhash:3190584-0!canonical and timestamp 20200515010358 and revision id 419222543
 -->
</div><noscript><img src="//commons.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript></div>
		<div class="printfooter">Retrieved from "<a dir="ltr" href="https://commons.wikimedia.org/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;oldid=419222543">https://commons.wikimedia.org/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;oldid=419222543</a>"</div>
		<div id="catlinks" class="catlinks" data-mw="interface"><div id="mw-hidden-catlinks" class="mw-hidden-catlinks mw-hidden-cats-user-shown">Hidden category: <ul><li><a href="/wiki/Category:Gadget_scripts" title="Category:Gadget scripts">Gadget scripts</a></li></ul></div></div>
		<div class="visualClear"></div>
		
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		<div id="p-personal" class="vector-menu" aria-labelledby="p-personal-label" 
	 >
	<h3 id="p-personal-label">
		<span>Personal tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="pt-uls" class="active"><a href="#" class="uls-trigger">English</a></li><li id="pt-anonuserpage">Not logged in</li><li id="pt-anontalk"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n">Talk</a></li><li id="pt-anoncontribs"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y">Contributions</a></li><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=MediaWiki+talk%3AGadget-HotCat.js" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=MediaWiki+talk%3AGadget-HotCat.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o">Log in</a></li></ul>
		
	</div>
</div>


		<div id="left-navigation">
			<div id="p-namespaces" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-namespaces-label" 
	 >
	<h3 id="p-namespaces-label">
		<span>Namespaces</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-nstab-mediawiki"><a href="/wiki/MediaWiki:Gadget-HotCat.js" title="View the system message [c]" accesskey="c">Interface page</a></li><li id="ca-talk" class="selected"><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js" rel="discussion" title="Discussion about the content page [t]" accesskey="t">Discussion</a></li></ul>
		
	</div>
</div>


			<div id="p-variants" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-variants-label" 
	 >
	<input type="checkbox" class="vectorMenuCheckbox vector-menu-checkbox" aria-labelledby="p-variants-label" />
	<h3 id="p-variants-label">
		<span>Variants</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</div>


		</div>
		<div id="right-navigation">
			<div id="p-views" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-views-label" 
	 >
	<h3 id="p-views-label">
		<span>Views</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-view" class="collapsible selected"><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js">View</a></li><li id="ca-edit" class="collapsible istalk"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit" title="Edit this page [e]" accesskey="e">Edit</a></li><li id="ca-addsection" class="collapsible"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=new" title="Start a new section [+]" accesskey="+">Add topic</a></li><li id="ca-history" class="collapsible"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=history" title="Past revisions of this page [h]" accesskey="h">History</a></li></ul>
		
	</div>
</div>


			<div id="p-cactions" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-cactions-label" 
	 >
	<input type="checkbox" class="vectorMenuCheckbox vector-menu-checkbox" aria-labelledby="p-cactions-label" />
	<h3 id="p-cactions-label">
		<span>More</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</div>


			<div id="p-search" role="search">
	<h3 >
		<label for="searchInput">Search</label>
	</h3>
	<form action="/w/index.php" id="searchform">
		<div id="simpleSearch">
			<input type="search" name="search" placeholder="Search Wikimedia Commons" title="Search Wikimedia Commons [f]" accesskey="f" id="searchInput"/>
			<input type="hidden" name="title" value="Special:Search">
			<input type="submit" name="fulltext" value="Search" title="Search the pages for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/>
			<input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>
		</div>
	</form>
</div>

		</div>
	</div>
	
<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a  title="Visit the main page" class="mw-wiki-logo" href="/wiki/Main_Page"></a>
	</div>
	<div id="p-navigation" class="vector-menu vector-menu-portal portal portal-first" aria-labelledby="p-navigation-label" 
	 >
	<h3 id="p-navigation-label">
		<span>Navigate</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-mainpage-description"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z">Main page</a></li><li id="n-welcome"><a href="/wiki/Commons:Welcome">Welcome</a></li><li id="n-portal"><a href="/wiki/Commons:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li><li id="n-village-pump"><a href="/wiki/Commons:Village_pump">Village pump</a></li><li id="n-help"><a href="/wiki/Special:MyLanguage/Help:Contents" title="The place to find out">Help center</a></li></ul>
		
	</div>
</div>


	<div id="p-participate" class="vector-menu vector-menu-portal portal" aria-labelledby="p-participate-label" 
	 >
	<h3 id="p-participate-label">
		<span>Participate</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-uploadbtn"><a href="/wiki/Special:UploadWizard">Upload file</a></li><li id="n-recentchanges"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r">Recent changes</a></li><li id="n-latestfiles"><a href="/wiki/Special:NewFiles">Latest files</a></li><li id="n-randomimage"><a href="/wiki/Special:Random/File" title="Load a random file [x]" accesskey="x">Random file</a></li><li id="n-contact"><a href="/wiki/Commons:Contact_us">Contact us</a></li></ul>
		
	</div>
</div>

<div id="p-coll-print_export" class="vector-menu-empty emptyPortlet vector-menu vector-menu-portal portal" aria-labelledby="p-coll-print_export-label" 
	 >
	<h3 id="p-coll-print_export-label">
		<span>Print/export</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</div>

<div id="p-tb" class="vector-menu vector-menu-portal portal" aria-labelledby="p-tb-label" 
	 >
	<h3 id="p-tb-label">
		<span>Tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="t-whatlinkshere"><a href="/wiki/Special:WhatLinksHere/MediaWiki_talk:Gadget-HotCat.js" title="A list of all wiki pages that link here [j]" accesskey="j">What links here</a></li><li id="t-recentchangeslinked"><a href="/wiki/Special:RecentChangesLinked/MediaWiki_talk:Gadget-HotCat.js" rel="nofollow" title="Recent changes in pages linked from this page [k]" accesskey="k">Related changes</a></li><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-permalink"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;oldid=419222543" title="Permanent link to this revision of the page">Permanent link</a></li><li id="t-info"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=info" title="More information about this page">Page information</a></li></ul>
		
	</div>
</div>


</div>

</div>

<div id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-info" >
		<li id="footer-info-lastmod"> This page was last edited on 15 May 2020, at 01:03.</li>
		<li id="footer-info-copyright">Files are available under licenses specified on their description page. All structured data from the file and property namespaces is available under the <a href="https://creativecommons.org/publicdomain/zero/1.0/" title="Definition of the Creative Commons CC0 License">Creative Commons CC0 License</a>; all unstructured text is available under the <a href="https://creativecommons.org/licenses/by-sa/3.0/" title="Definition of the Creative Commons Attribution/Share-Alike License">Creative Commons Attribution-ShareAlike License</a>;
additional terms may apply.
By using this site, you agree to the <a href="//foundation.wikimedia.org/wiki/Terms_of_Use" title="Wikimedia Foundation Terms of Use">Terms of Use</a> and the <a href="//foundation.wikimedia.org/wiki/Privacy_policy" title="Wikimedia Foundation Privacy Policy">Privacy Policy</a>.</li>
	</ul>
	<ul id="footer-places" >
		<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy" class="extiw" title="wmf:Privacy policy">Privacy policy</a></li>
		<li id="footer-places-about"><a href="/wiki/Commons:Welcome" title="Commons:Welcome">About Wikimedia Commons</a></li>
		<li id="footer-places-disclaimer"><a href="/wiki/Commons:General_disclaimer" title="Commons:General disclaimer">Disclaimers</a></li>
		<li id="footer-places-developers"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li>
		<li id="footer-places-statslink"><a href="https://stats.wikimedia.org/#/commons.wikimedia.org">Statistics</a></li>
		<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
		<li id="footer-places-mobileview"><a href="//commons.m.wikimedia.org/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
	</ul>
	<ul id="footer-icons" class="noprint">
		<li id="footer-copyrightico"><a href="https://wikimediafoundation.org/"><img src="/static/images/wikimedia-button.png" srcset="/static/images/wikimedia-button-1.5x.png 1.5x, /static/images/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation" loading="lazy" /></a></li>
		<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/static/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/poweredby_mediawiki_132x47.png 1.5x, /static/images/poweredby_mediawiki_176x62.png 2x" width="88" height="31"/></a></li>
	</ul>
	<div style="clear: both;"></div>
</div>


<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"limitreport":{"cputime":"0.120","walltime":"0.187","ppvisitednodes":{"value":855,"limit":1000000},"postexpandincludesize":{"value":71578,"limit":2097152},"templateargumentsize":{"value":20501,"limit":2097152},"expansiondepth":{"value":20,"limit":40},"expensivefunctioncount":{"value":3,"limit":500},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":464,"limit":5000000},"entityaccesscount":{"value":0,"limit":400},"timingprofile":["100.00%  129.442      1 -total"," 50.49%   65.356      1 Template:Gadget-talk"," 47.31%   61.242      3 Template:Tmbox"," 44.76%   57.938      3 Template:Tmbox/core"," 28.93%   37.452      1 Template:Archives"," 19.11%   24.738      1 Template:Autotranslate"," 18.30%   23.687      2 Template:Lang_links"," 12.27%   15.886      1 Template:Support"," 12.26%   15.866      1 Template:Gadget-desc"," 10.35%   13.398      1 MediaWiki:Gadget-HotCat.js/lang"]},"scribunto":{"limitreport-timeusage":{"value":"0.007","limit":"10.000"},"limitreport-memusage":{"value":650627,"limit":52428800}},"cachereport":{"origin":"mw1335","timestamp":"20200515010358","ttl":2592000,"transientcontent":false}}});mw.config.set({"wgBackendResponseTime":145,"wgHostname":"mw1355"});});</script></body></html>
