
<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>Mw.TMHGalleryHook.js - Wikimedia Commons</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":!1,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"77bd2da0-ae73-46c3-94cd-ded1fac4014e","wgCSPNonce":!1,"wgCanonicalNamespace":"","wgCanonicalSpecialPageName":!1,"wgNamespaceNumber":0,"wgPageName":"Mw.TMHGalleryHook.js","wgTitle":"Mw.TMHGalleryHook.js","wgCurRevisionId":0,"wgRevisionId":0,"wgArticleId":0,"wgIsArticle":!0,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"Mw.TMHGalleryHook.js","wgRelevantArticleId":0,"wgIsProbablyEditable":!0,"wgRelevantPageIsProbablyEditable":!0,"wgMediaViewerOnClick":!0,"wgMediaViewerEnabledByDefault":!1,"wgVisualEditor":{"pageLanguageCode":"en",
"pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":!0,"nearby":!0,"watchlist":!0,"tagline":!0},"wgWMESchemaEditAttemptStepOversample":!1,"wgULSCurrentAutonym":"English","wgNoticeProject":"commons","wbUserSpecifiedLanguages":[],"wbCopyright":{"version":"wikibase-1","messageHtml":"By clicking \"publish\", you agree to the \u003Ca href=\"/wiki/Commons:Copyrights\" class=\"mw-redirect\" title=\"Commons:Copyrights\"\u003Eterms of use\u003C/a\u003E, and you irrevocably agree to release your contribution under the \u003Ca rel=\"nofollow\" class=\"external text\" href=\"https://creativecommons.org/publicdomain/zero/1.0/\"\u003ECreative Commons CC0 License\u003C/a\u003E."},"wbBadgeItems":[],"wbMultiLingualStringLimit":250,"wbTaintedReferencesEnabled":!1,"wgCentralAuthMobileDomain":!1,"wgEditSubmitButtonLabelPublish":!0,"wbmiDefaultProperties":["P180"],"wbmiPropertyTitles":{"P180":"Items portrayed in this file"},"wbmiPropertyTypes"
:{"P180":"wikibase-item"},"wbmiSearchTitles":{"P180":"files depicting…"},"wbmiHelpUrls":{"P180":"https://commons.wikimedia.org/wiki/Special:MyLanguage/Commons:Depicts"},"wbmiExternalEntitySearchBaseUri":"https://www.wikidata.org/w/api.php","wbmiMediaInfoEnableSearch":!1,"wbmiRepoApiUrl":"/w/api.php","wbmiSupportedDataTypes":["wikibase-item","string","quantity","time","monolingualtext","external-id","globe-coordinate","url"]};RLSTATE={"ext.gadget.Long-Image-Names-in-Categories":"ready","ext.globalCssJs.user.styles":"ready","site.styles":"ready","noscript":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","user":"ready","user.options":"loading","skins.vector.styles.legacy":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.uls.pt":"ready","ext.wikimediaBadges":"ready"};RLPAGEMODULES=["site","mediawiki.page.startup","mediawiki.page.ready","skins.vector.legacy.js","ext.gadget.Slideshow","ext.gadget.ZoomViewer","ext.gadget.CollapsibleTemplates",
"ext.gadget.fastcci","ext.gadget.Stockphoto","ext.gadget.WatchlistNotice","ext.gadget.AjaxQuickDelete","ext.gadget.WikiMiniAtlas","ext.gadget.LanguageSelect","ext.centralauth.centralautologin","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.citoid.wikibase.init","ext.eventLogging","ext.wikimediaEvents","ext.wikimediaEvents.wikibase","ext.navigationTiming","ext.uls.compactlinks","ext.uls.interface","wikibase.mediainfo.search","ext.centralNotice.geoIP","ext.centralNotice.startUp"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@1hzgi",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.uls.pt%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediaBadges%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.Long-Image-Names-in-Categories&amp;only=styles&amp;skin=vector"/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.35.0-wmf.35"/>
<meta name="referrer" content="origin"/>
<meta name="referrer" content="origin-when-crossorigin"/>
<meta name="referrer" content="origin-when-cross-origin"/>
<meta name="robots" content="noindex,nofollow"/>
<link rel="alternate" type="application/x-wiki" title="Edit" href="/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=edit"/>
<link rel="edit" title="Edit" href="/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=edit"/>
<link rel="apple-touch-icon" href="/static/apple-touch/commons.png"/>
<link rel="shortcut icon" href="/static/favicon/commons.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikimedia Commons"/>
<link rel="EditURI" type="application/rsd+xml" href="//commons.wikimedia.org/w/api.php?action=rsd"/>
<link rel="license" href="//creativecommons.org/licenses/by-sa/3.0/"/>
<link rel="alternate" type="application/atom+xml" title="Wikimedia Commons Atom feed" href="/w/index.php?title=Special:RecentChanges&amp;feed=atom"/>
<link rel="canonical" href="https://commons.wikimedia.org/wiki/Mw.TMHGalleryHook.js"/>
<link rel="dns-prefetch" href="//login.wikimedia.org"/>
<link rel="dns-prefetch" href="//meta.wikimedia.org" />
<!--[if lt IE 9]><script src="/w/resources/lib/html5shiv/html5shiv.js"></script><![endif]-->
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-0 ns-subject mw-editable page-Mw_TMHGalleryHook_js rootpage-Mw_TMHGalleryHook_js skin-vector action-view skin-vector-legacy">
<div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
		<div id="siteNotice" class="mw-body-content"><!-- CentralNotice --></div>
	<div class="mw-indicators mw-body-content">
</div>

	<h1 id="firstHeading" class="firstHeading" lang="en">Mw.TMHGalleryHook.js</h1>
	
	<div id="bodyContent" class="mw-body-content">
		<div id="siteSub" class="noprint">From Wikimedia Commons, the free media repository</div>
		<div id="contentSub"></div>
		
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#p-search">Jump to search</a>
		<div id="mw-content-text" lang="en" dir="ltr" class="mw-content-ltr"><div class="noarticletext mw-content-ltr" dir="ltr" lang="en">
<p><span class="plainlinks nourlexpansion">This page does not currently exist. You can <a class="external text" href="https://commons.wikimedia.org/w/index.php?title=Special:Search/Mw.TMHGalleryHook.js&amp;fulltext=Search">search for this page title</a> in other pages or <a class="external text" href="https://commons.wikimedia.org/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=edit">create this page</a>.</span>
</p>
</div><noscript><img src="//commons.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript></div>
		<div class="printfooter">Retrieved from "<a dir="ltr" href="https://commons.wikimedia.org/wiki/Mw.TMHGalleryHook.js">https://commons.wikimedia.org/wiki/Mw.TMHGalleryHook.js</a>"</div>
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
		<div class="visualClear"></div>
		
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		<div id="p-personal" class="vector-menu" aria-labelledby="p-personal-label" 
	 >
	<h3 id="p-personal-label">
		<span>Personal tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="pt-uls" class="active"><a href="#" class="uls-trigger">English</a></li><li id="pt-anonuserpage">Not logged in</li><li id="pt-anontalk"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n">Talk</a></li><li id="pt-anoncontribs"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y">Contributions</a></li><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=Mw.TMHGalleryHook.js" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=Mw.TMHGalleryHook.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o">Log in</a></li></ul>
		
	</div>
</div>


		<div id="left-navigation">
			<div id="p-namespaces" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-namespaces-label" 
	 >
	<h3 id="p-namespaces-label">
		<span>Namespaces</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-nstab-main" class="selected new"><a href="/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=edit&amp;redlink=1" title="View the content page (page does not exist) [c]" accesskey="c">Gallery</a></li><li id="ca-talk" class="new"><a href="/w/index.php?title=Talk:Mw.TMHGalleryHook.js&amp;action=edit&amp;redlink=1" rel="discussion" title="Discussion about the content page (page does not exist) [t]" accesskey="t">Discussion</a></li></ul>
		
	</div>
</div>


			<div id="p-variants" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-variants-label" 
	 >
	<input type="checkbox" class="vectorMenuCheckbox vector-menu-checkbox" aria-labelledby="p-variants-label" />
	<h3 id="p-variants-label">
		<span>Variants</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</div>


		</div>
		<div id="right-navigation">
			<div id="p-views" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-views-label" 
	 >
	<h3 id="p-views-label">
		<span>Views</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-edit" class="collapsible"><a href="/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=edit" title="Edit this page [e]" accesskey="e">Create</a></li></ul>
		
	</div>
</div>


			<div id="p-cactions" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-cactions-label" 
	 >
	<input type="checkbox" class="vectorMenuCheckbox vector-menu-checkbox" aria-labelledby="p-cactions-label" />
	<h3 id="p-cactions-label">
		<span>More</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</div>


			<div id="p-search" role="search">
	<h3 >
		<label for="searchInput">Search</label>
	</h3>
	<form action="/w/index.php" id="searchform">
		<div id="simpleSearch">
			<input type="search" name="search" placeholder="Search Wikimedia Commons" title="Search Wikimedia Commons [f]" accesskey="f" id="searchInput"/>
			<input type="hidden" name="title" value="Special:Search">
			<input type="submit" name="fulltext" value="Search" title="Search the pages for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/>
			<input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>
		</div>
	</form>
</div>

		</div>
	</div>
	
<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a  title="Visit the main page" class="mw-wiki-logo" href="/wiki/Main_Page"></a>
	</div>
	<div id="p-navigation" class="vector-menu vector-menu-portal portal portal-first" aria-labelledby="p-navigation-label" 
	 >
	<h3 id="p-navigation-label">
		<span>Navigate</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-mainpage-description"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z">Main page</a></li><li id="n-welcome"><a href="/wiki/Commons:Welcome">Welcome</a></li><li id="n-portal"><a href="/wiki/Commons:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li><li id="n-village-pump"><a href="/wiki/Commons:Village_pump">Village pump</a></li><li id="n-help"><a href="/wiki/Special:MyLanguage/Help:Contents" title="The place to find out">Help center</a></li></ul>
		
	</div>
</div>


	<div id="p-participate" class="vector-menu vector-menu-portal portal" aria-labelledby="p-participate-label" 
	 >
	<h3 id="p-participate-label">
		<span>Participate</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-uploadbtn"><a href="/wiki/Special:UploadWizard">Upload file</a></li><li id="n-recentchanges"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r">Recent changes</a></li><li id="n-latestfiles"><a href="/wiki/Special:NewFiles">Latest files</a></li><li id="n-randomimage"><a href="/wiki/Special:Random/File" title="Load a random file [x]" accesskey="x">Random file</a></li><li id="n-contact"><a href="/wiki/Commons:Contact_us">Contact us</a></li></ul>
		
	</div>
</div>

<div id="p-coll-print_export" class="vector-menu-empty emptyPortlet vector-menu vector-menu-portal portal" aria-labelledby="p-coll-print_export-label" 
	 >
	<h3 id="p-coll-print_export-label">
		<span>Print/export</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</div>

<div id="p-tb" class="vector-menu vector-menu-portal portal" aria-labelledby="p-tb-label" 
	 >
	<h3 id="p-tb-label">
		<span>Tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="t-whatlinkshere"><a href="/wiki/Special:WhatLinksHere/Mw.TMHGalleryHook.js" title="A list of all wiki pages that link here [j]" accesskey="j">What links here</a></li><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-info"><a href="/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=info" title="More information about this page">Page information</a></li></ul>
		
	</div>
</div>


</div>

</div>

<div id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-places" >
		<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy" class="extiw" title="wmf:Privacy policy">Privacy policy</a></li>
		<li id="footer-places-about"><a href="/wiki/Commons:Welcome" title="Commons:Welcome">About Wikimedia Commons</a></li>
		<li id="footer-places-disclaimer"><a href="/wiki/Commons:General_disclaimer" title="Commons:General disclaimer">Disclaimers</a></li>
		<li id="footer-places-developers"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li>
		<li id="footer-places-statslink"><a href="https://stats.wikimedia.org/#/commons.wikimedia.org">Statistics</a></li>
		<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
		<li id="footer-places-mobileview"><a href="//commons.m.wikimedia.org/w/index.php?title=Mw.TMHGalleryHook.js&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
	</ul>
	<ul id="footer-icons" class="noprint">
		<li id="footer-copyrightico"><a href="https://wikimediafoundation.org/"><img src="/static/images/wikimedia-button.png" srcset="/static/images/wikimedia-button-1.5x.png 1.5x, /static/images/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation" loading="lazy" /></a></li>
		<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/static/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/poweredby_mediawiki_132x47.png 1.5x, /static/images/poweredby_mediawiki_176x62.png 2x" width="88" height="31"/></a></li>
	</ul>
	<div style="clear: both;"></div>
</div>


<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgBackendResponseTime":166,"wgHostname":"mw1352"});});</script></body></html>
