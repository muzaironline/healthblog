
<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>Pages that link to "Skins.vector.legacy.js" - Wikimedia Commons</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":!0,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"2279f998-6f31-4429-972a-6148efd02af4","wgCSPNonce":!1,"wgCanonicalNamespace":"Special","wgCanonicalSpecialPageName":"Whatlinkshere","wgNamespaceNumber":-1,"wgPageName":"Special:WhatLinksHere/skins.vector.legacy.js","wgTitle":"WhatLinksHere/skins.vector.legacy.js","wgCurRevisionId":0,"wgRevisionId":0,"wgArticleId":0,"wgIsArticle":!1,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"Skins.vector.legacy.js","wgRelevantArticleId":0,"wgIsProbablyEditable":!1,"wgRelevantPageIsProbablyEditable":!0,"wgMediaViewerOnClick":!0,
"wgMediaViewerEnabledByDefault":!1,"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":!0,"nearby":!0,"watchlist":!0,"tagline":!0},"wgWMESchemaEditAttemptStepOversample":!1,"wgULSCurrentAutonym":"English","wgNoticeProject":"commons","wgCentralAuthMobileDomain":!1,"wgEditSubmitButtonLabelPublish":!0,"wbmiDefaultProperties":["P180"],"wbmiPropertyTitles":{"P180":"Items portrayed in this file"},"wbmiPropertyTypes":{"P180":"wikibase-item"},"wbmiSearchTitles":{"P180":"files depicting…"},"wbmiHelpUrls":{"P180":"https://commons.wikimedia.org/wiki/Special:MyLanguage/Commons:Depicts"},"wbmiExternalEntitySearchBaseUri":"https://www.wikidata.org/w/api.php","wbmiMediaInfoEnableSearch":!1,"wbmiRepoApiUrl":"/w/api.php","wbmiSupportedDataTypes":["wikibase-item","string","quantity","time","monolingualtext","external-id","globe-coordinate","url"]};RLSTATE={
"ext.gadget.Long-Image-Names-in-Categories":"ready","ext.globalCssJs.user.styles":"ready","site.styles":"ready","noscript":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","user":"ready","user.options":"loading","mediawiki.helplink":"ready","skins.vector.styles.legacy":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.uls.pt":"ready","ext.wikimediaBadges":"ready"};RLPAGEMODULES=["site","mediawiki.page.startup","mediawiki.page.ready","skins.vector.legacy.js","ext.gadget.Slideshow","ext.gadget.ZoomViewer","ext.gadget.CollapsibleTemplates","ext.gadget.fastcci","ext.gadget.Stockphoto","ext.gadget.WatchlistNotice","ext.gadget.AjaxQuickDelete","ext.gadget.WikiMiniAtlas","ext.gadget.LanguageSelect","ext.centralauth.centralautologin","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging","ext.wikimediaEvents","ext.wikimediaEvents.wikibase","ext.navigationTiming","ext.uls.compactlinks","ext.uls.interface",
"wikibase.mediainfo.search","ext.centralNotice.geoIP"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@1hzgi",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.uls.pt%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediaBadges%7Cmediawiki.helplink%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.Long-Image-Names-in-Categories&amp;only=styles&amp;skin=vector"/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.35.0-wmf.35"/>
<meta name="referrer" content="origin"/>
<meta name="referrer" content="origin-when-crossorigin"/>
<meta name="referrer" content="origin-when-cross-origin"/>
<meta name="robots" content="noindex,nofollow"/>
<link rel="apple-touch-icon" href="/static/apple-touch/commons.png"/>
<link rel="shortcut icon" href="/static/favicon/commons.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikimedia Commons"/>
<link rel="EditURI" type="application/rsd+xml" href="//commons.wikimedia.org/w/api.php?action=rsd"/>
<link rel="license" href="//creativecommons.org/licenses/by-sa/3.0/"/>
<link rel="alternate" type="application/atom+xml" title="Wikimedia Commons Atom feed" href="/w/index.php?title=Special:RecentChanges&amp;feed=atom"/>
<link rel="canonical" href="https://commons.wikimedia.org/wiki/Special:WhatLinksHere/skins.vector.legacy.js"/>
<link rel="dns-prefetch" href="//login.wikimedia.org"/>
<!--[if lt IE 9]><script src="/w/resources/lib/html5shiv/html5shiv.js"></script><![endif]-->
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns--1 ns-special mw-special-Whatlinkshere page-Special_WhatLinksHere_skins_vector_legacy_js rootpage-Special_WhatLinksHere_skins_vector_legacy_js skin-vector action-view skin-vector-legacy">
<div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
		<div id="siteNotice" class="mw-body-content"><!-- CentralNotice --></div>
	<div class="mw-indicators mw-body-content">
<div id="mw-indicator-mw-helplink" class="mw-indicator"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/Help:What_links_here" target="_blank" class="mw-helplink">Help</a></div>
</div>

	<h1 id="firstHeading" class="firstHeading" lang="en">Pages that link to "Skins.vector.legacy.js"</h1>
	
	<div id="bodyContent" class="mw-body-content">
		
		<div id="contentSub">← <a href="/w/index.php?title=Skins.vector.legacy.js&amp;action=edit&amp;redlink=1" class="new" title="Skins.vector.legacy.js (page does not exist)">Skins.vector.legacy.js</a></div>
		
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#p-search">Jump to search</a>
		<div id="mw-content-text"><form action="/w/index.php"><input type="hidden" value="Special:WhatLinksHere" name="title"/><fieldset>
<legend>What links here</legend>
<label for="mw-whatlinkshere-target" class="mw-searchInput">Page:</label> <input name="target" size="40" value="Skins.vector.legacy.js" id="mw-whatlinkshere-target" class="mw-searchInput" /> <label for="namespace">Namespace:</label> <select class="namespaceselector" id="namespace" name="namespace">
<option value="" selected="">all</option>
<option value="0">(Gallery)</option>
<option value="1">Talk</option>
<option value="2">User</option>
<option value="3">User talk</option>
<option value="4">Commons</option>
<option value="5">Commons talk</option>
<option value="6">File</option>
<option value="7">File talk</option>
<option value="8">MediaWiki</option>
<option value="9">MediaWiki talk</option>
<option value="10">Template</option>
<option value="11">Template talk</option>
<option value="12">Help</option>
<option value="13">Help talk</option>
<option value="14">Category</option>
<option value="15">Category talk</option>
<option value="100">Creator</option>
<option value="101">Creator talk</option>
<option value="102">TimedText</option>
<option value="103">TimedText talk</option>
<option value="104">Sequence</option>
<option value="105">Sequence talk</option>
<option value="106">Institution</option>
<option value="107">Institution talk</option>
<option value="460">Campaign</option>
<option value="461">Campaign talk</option>
<option value="486">Data</option>
<option value="487">Data talk</option>
<option value="490">GWToolset</option>
<option value="491">GWToolset talk</option>
<option value="828">Module</option>
<option value="829">Module talk</option>
<option value="1198">Translations</option>
<option value="1199">Translations talk</option>
<option value="2300">Gadget</option>
<option value="2301">Gadget talk</option>
<option value="2302">Gadget definition</option>
<option value="2303">Gadget definition talk</option>
<option value="2600">Topic</option>
</select> <input name="invert" type="checkbox" value="1" id="nsinvert" title="Check this box to hide links from pages within the selected namespace." /> <label for="nsinvert" title="Check this box to hide links from pages within the selected namespace.">Invert selection</label> <input type="submit" value="Go"/></fieldset></form>
<fieldset>
<legend>Filters</legend>
<a href="/w/index.php?title=Special:WhatLinksHere/Skins.vector.legacy.js&amp;hidetrans=1" title="Special:WhatLinksHere/Skins.vector.legacy.js">Hide</a> transclusions | <a href="/w/index.php?title=Special:WhatLinksHere/Skins.vector.legacy.js&amp;hidelinks=1" title="Special:WhatLinksHere/Skins.vector.legacy.js">Hide</a> links | <a href="/w/index.php?title=Special:WhatLinksHere/Skins.vector.legacy.js&amp;hideredirs=1" title="Special:WhatLinksHere/Skins.vector.legacy.js">Hide</a> redirects
</fieldset>
<p>No pages link to <strong><a href="/w/index.php?title=Skins.vector.legacy.js&amp;action=edit&amp;redlink=1" class="new" title="Skins.vector.legacy.js (page does not exist)">Skins.vector.legacy.js</a></strong>.
</p><noscript><img src="//commons.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript></div>
		<div class="printfooter">Retrieved from "<a dir="ltr" href="https://commons.wikimedia.org/wiki/Special:WhatLinksHere/skins.vector.legacy.js">https://commons.wikimedia.org/wiki/Special:WhatLinksHere/skins.vector.legacy.js</a>"</div>
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
		<div class="visualClear"></div>
		
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		<div id="p-personal" class="vector-menu" aria-labelledby="p-personal-label" 
	 >
	<h3 id="p-personal-label">
		<span>Personal tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="pt-uls" class="active"><a href="#" class="uls-trigger">English</a></li><li id="pt-anonuserpage">Not logged in</li><li id="pt-anontalk"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n">Talk</a></li><li id="pt-anoncontribs"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y">Contributions</a></li><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=Special%3AWhatLinksHere%2Fskins.vector.legacy.js" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=Special%3AWhatLinksHere%2Fskins.vector.legacy.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o">Log in</a></li></ul>
		
	</div>
</div>


		<div id="left-navigation">
			<div id="p-namespaces" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-namespaces-label" 
	 >
	<h3 id="p-namespaces-label">
		<span>Namespaces</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-nstab-main" class="selected new"><a href="/w/index.php?title=Skins.vector.legacy.js&amp;action=edit&amp;redlink=1" title="View the content page (page does not exist) [c]" accesskey="c">Gallery</a></li><li id="ca-talk" class="new"><a href="/w/index.php?title=Talk:Skins.vector.legacy.js&amp;action=edit&amp;redlink=1" rel="discussion" title="Discussion about the content page (page does not exist) [t]" accesskey="t">Discussion</a></li></ul>
		
	</div>
</div>


			<div id="p-variants" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-variants-label" 
	 >
	<input type="checkbox" class="vectorMenuCheckbox vector-menu-checkbox" aria-labelledby="p-variants-label" />
	<h3 id="p-variants-label">
		<span>Variants</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</div>


		</div>
		<div id="right-navigation">
			<div id="p-views" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-views-label" 
	 >
	<h3 id="p-views-label">
		<span>Views</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-edit" class="collapsible"><a href="/w/index.php?title=Skins.vector.legacy.js&amp;action=edit" title="Edit this page [e]" accesskey="e">Create</a></li></ul>
		
	</div>
</div>


			<div id="p-cactions" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-cactions-label" 
	 >
	<input type="checkbox" class="vectorMenuCheckbox vector-menu-checkbox" aria-labelledby="p-cactions-label" />
	<h3 id="p-cactions-label">
		<span>More</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</div>


			<div id="p-search" role="search">
	<h3 >
		<label for="searchInput">Search</label>
	</h3>
	<form action="/w/index.php" id="searchform">
		<div id="simpleSearch">
			<input type="search" name="search" placeholder="Search Wikimedia Commons" title="Search Wikimedia Commons [f]" accesskey="f" id="searchInput"/>
			<input type="hidden" name="title" value="Special:Search">
			<input type="submit" name="fulltext" value="Search" title="Search the pages for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/>
			<input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>
		</div>
	</form>
</div>

		</div>
	</div>
	
<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a  title="Visit the main page" class="mw-wiki-logo" href="/wiki/Main_Page"></a>
	</div>
	<div id="p-navigation" class="vector-menu vector-menu-portal portal portal-first" aria-labelledby="p-navigation-label" 
	 >
	<h3 id="p-navigation-label">
		<span>Navigate</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-mainpage-description"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z">Main page</a></li><li id="n-welcome"><a href="/wiki/Commons:Welcome">Welcome</a></li><li id="n-portal"><a href="/wiki/Commons:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li><li id="n-village-pump"><a href="/wiki/Commons:Village_pump">Village pump</a></li><li id="n-help"><a href="/wiki/Special:MyLanguage/Help:Contents" title="The place to find out">Help center</a></li></ul>
		
	</div>
</div>


	<div id="p-participate" class="vector-menu vector-menu-portal portal" aria-labelledby="p-participate-label" 
	 >
	<h3 id="p-participate-label">
		<span>Participate</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-uploadbtn"><a href="/wiki/Special:UploadWizard">Upload file</a></li><li id="n-recentchanges"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r">Recent changes</a></li><li id="n-latestfiles"><a href="/wiki/Special:NewFiles">Latest files</a></li><li id="n-randomimage"><a href="/wiki/Special:Random/File" title="Load a random file [x]" accesskey="x">Random file</a></li><li id="n-contact"><a href="/wiki/Commons:Contact_us">Contact us</a></li></ul>
		
	</div>
</div>

<div id="p-coll-print_export" class="vector-menu-empty emptyPortlet vector-menu vector-menu-portal portal" aria-labelledby="p-coll-print_export-label" 
	 >
	<h3 id="p-coll-print_export-label">
		<span>Print/export</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</div>

<div id="p-tb" class="vector-menu vector-menu-portal portal" aria-labelledby="p-tb-label" 
	 >
	<h3 id="p-tb-label">
		<span>Tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-print"><a href="/w/index.php?title=Special:WhatLinksHere/skins.vector.legacy.js&amp;printable=yes" rel="alternate" title="Printable version of this page [p]" accesskey="p">Printable version</a></li></ul>
		
	</div>
</div>


</div>

</div>

<div id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-places" >
		<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy" class="extiw" title="wmf:Privacy policy">Privacy policy</a></li>
		<li id="footer-places-about"><a href="/wiki/Commons:Welcome" title="Commons:Welcome">About Wikimedia Commons</a></li>
		<li id="footer-places-disclaimer"><a href="/wiki/Commons:General_disclaimer" title="Commons:General disclaimer">Disclaimers</a></li>
		<li id="footer-places-developers"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li>
		<li id="footer-places-statslink"><a href="https://stats.wikimedia.org/#/commons.wikimedia.org">Statistics</a></li>
		<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
		<li id="footer-places-mobileview"><a href="//commons.m.wikimedia.org/w/index.php?title=Special:WhatLinksHere/skins.vector.legacy.js&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
	</ul>
	<ul id="footer-icons" class="noprint">
		<li id="footer-copyrightico"><a href="https://wikimediafoundation.org/"><img src="/static/images/wikimedia-button.png" srcset="/static/images/wikimedia-button-1.5x.png 1.5x, /static/images/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation" loading="lazy" /></a></li>
		<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/static/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/poweredby_mediawiki_132x47.png 1.5x, /static/images/poweredby_mediawiki_176x62.png 2x" width="88" height="31"/></a></li>
	</ul>
	<div style="clear: both;"></div>
</div>


<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgBackendResponseTime":81,"wgHostname":"mw1369"});});</script></body></html>
