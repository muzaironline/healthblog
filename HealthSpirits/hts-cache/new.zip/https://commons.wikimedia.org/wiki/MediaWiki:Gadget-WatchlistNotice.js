
<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>MediaWiki:Gadget-WatchlistNotice.js - Wikimedia Commons</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":!1,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"f8db446c-d39e-4df5-8862-6363b31a2b35","wgCSPNonce":!1,"wgCanonicalNamespace":"MediaWiki","wgCanonicalSpecialPageName":!1,"wgNamespaceNumber":8,"wgPageName":"MediaWiki:Gadget-WatchlistNotice.js","wgTitle":"Gadget-WatchlistNotice.js","wgCurRevisionId":97311724,"wgRevisionId":97311724,"wgArticleId":26248284,"wgIsArticle":!0,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgPageContentLanguage":"en","wgPageContentModel":"javascript","wgRelevantPageName":"MediaWiki:Gadget-WatchlistNotice.js","wgRelevantArticleId":26248284,"wgIsProbablyEditable":!1,"wgRelevantPageIsProbablyEditable":!1,"wgRestrictionEdit":[],
"wgRestrictionMove":[],"wgMediaViewerOnClick":!0,"wgMediaViewerEnabledByDefault":!1,"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":!0,"nearby":!0,"watchlist":!0,"tagline":!0},"wgWMESchemaEditAttemptStepOversample":!1,"wgULSCurrentAutonym":"English","wgNoticeProject":"commons","wbUserSpecifiedLanguages":[],"wgCentralAuthMobileDomain":!1,"wgEditSubmitButtonLabelPublish":!0,"wbmiDefaultProperties":["P180"],"wbmiPropertyTitles":{"P180":"Items portrayed in this file"},"wbmiPropertyTypes":{"P180":"wikibase-item"},"wbmiSearchTitles":{"P180":"files depicting…"},"wbmiHelpUrls":{"P180":"https://commons.wikimedia.org/wiki/Special:MyLanguage/Commons:Depicts"},"wbmiExternalEntitySearchBaseUri":"https://www.wikidata.org/w/api.php","wbmiMediaInfoEnableSearch":!1,"wbmiRepoApiUrl":"/w/api.php","wbmiSupportedDataTypes":["wikibase-item","string","quantity","time","monolingualtext",
"external-id","globe-coordinate","url"]};RLSTATE={"ext.gadget.Long-Image-Names-in-Categories":"ready","ext.globalCssJs.user.styles":"ready","site.styles":"ready","noscript":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","user":"ready","user.options":"loading","ext.pygments":"ready","skins.vector.styles.legacy":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.uls.pt":"ready","ext.wikimediaBadges":"ready"};RLPAGEMODULES=["site","mediawiki.page.startup","mediawiki.page.ready","skins.vector.legacy.js","ext.gadget.Slideshow","ext.gadget.ZoomViewer","ext.gadget.CollapsibleTemplates","ext.gadget.fastcci","ext.gadget.Stockphoto","ext.gadget.WatchlistNotice","ext.gadget.AjaxQuickDelete","ext.gadget.WikiMiniAtlas","ext.gadget.LanguageSelect","ext.centralauth.centralautologin","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging","ext.wikimediaEvents","ext.wikimediaEvents.wikibase","ext.navigationTiming",
"ext.uls.compactlinks","ext.uls.interface","wikibase.mediainfo.search","ext.centralNotice.geoIP","ext.centralNotice.startUp"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@1hzgi",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.pygments%2CwikimediaBadges%7Cext.uls.pt%7Cext.visualEditor.desktopArticleTarget.noscript%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.Long-Image-Names-in-Categories&amp;only=styles&amp;skin=vector"/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.35.0-wmf.35"/>
<meta name="referrer" content="origin"/>
<meta name="referrer" content="origin-when-crossorigin"/>
<meta name="referrer" content="origin-when-cross-origin"/>
<link rel="apple-touch-icon" href="/static/apple-touch/commons.png"/>
<link rel="shortcut icon" href="/static/favicon/commons.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikimedia Commons"/>
<link rel="EditURI" type="application/rsd+xml" href="//commons.wikimedia.org/w/api.php?action=rsd"/>
<link rel="license" href="//creativecommons.org/licenses/by-sa/3.0/"/>
<link rel="alternate" type="application/atom+xml" title="Wikimedia Commons Atom feed" href="/w/index.php?title=Special:RecentChanges&amp;feed=atom"/>
<link rel="canonical" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-WatchlistNotice.js"/>
<link rel="dns-prefetch" href="//login.wikimedia.org"/>
<link rel="dns-prefetch" href="//meta.wikimedia.org" />
<!--[if lt IE 9]><script src="/w/resources/lib/html5shiv/html5shiv.js"></script><![endif]-->
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-8 ns-subject page-MediaWiki_Gadget-WatchlistNotice_js rootpage-MediaWiki_Gadget-WatchlistNotice_js skin-vector action-view skin-vector-legacy">
<div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
		<div id="siteNotice" class="mw-body-content"><!-- CentralNotice --></div>
	<div class="mw-indicators mw-body-content">
</div>

	<h1 id="firstHeading" class="firstHeading" lang="en">MediaWiki:Gadget-WatchlistNotice.js</h1>
	
	<div id="bodyContent" class="mw-body-content">
		<div id="siteSub" class="noprint">From Wikimedia Commons, the free media repository</div>
		<div id="contentSub"></div>
		
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#p-search">Jump to search</a>
		<div id="mw-content-text" lang="en" dir="ltr" class="mw-content-ltr"><div id="mw-clearyourcache" lang="en" dir="ltr" class="mw-content-ltr">
<p><b>Note:</b> After saving, you have to <a href="https://en.wikipedia.org/wiki/Wikipedia:Bypass_your_cache" class="extiw" title="w:Wikipedia:Bypass your cache">bypass your browser's cache</a> to see the changes. <b>Internet Explorer:</b> press <i>Ctrl-F5</i>, <b>Mozilla:</b> hold down <i>Shift</i> while clicking <i>Reload</i> (or press <i>Ctrl-Shift-R</i>), <b>Opera/Konqueror:</b> press <i>F5</i>, <b>Safari:</b> hold down <i>Shift + Alt</i> while clicking <i>Reload</i>, <b>Chrome:</b> hold down <i>Shift</i> while clicking <i>Reload</i>
</p>
</div><div class="mw-parser-output"><div dir="ltr"><div class="mw-highlight"><pre><span></span><span class="cm">/**</span>
<span class="cm"> * WatchlistNotice</span>
<span class="cm"> * This is just a loader-gadget:</span>
<span class="cm"> * Only works at [[Special:Watchlist]]</span>
<span class="cm"> *</span>
<span class="cm"> * @rev 1 (2013-05-23)</span>
<span class="cm"> * @author Rillke, 2013</span>
<span class="cm"> */</span>
<span class="c1">// List the global variables for jsHint-Validation. Please make sure that it passes http://jshint.com/</span>
<span class="c1">// Scheme: globalVariable:allowOverwriting[, globalVariable:allowOverwriting][, globalVariable:allowOverwriting]</span>
<span class="cm">/*global jQuery:false, mediaWiki:false*/</span>

<span class="c1">// Load the heavy code only on pages where it is really required; Userlogin only loads site-JS after logging-in not at the login-form itself</span>

<span class="k">if</span> <span class="p">(</span><span class="nx">$</span><span class="p">.</span><span class="nx">inArray</span><span class="p">(</span><span class="nx">mw</span><span class="p">.</span><span class="nx">config</span><span class="p">.</span><span class="nx">get</span><span class="p">(</span><span class="s1">&#39;wgCanonicalSpecialPageName&#39;</span><span class="p">),</span> <span class="p">[</span><span class="s1">&#39;Watchlist&#39;</span><span class="p">,</span> <span class="s1">&#39;Userlogin&#39;</span><span class="p">])</span> <span class="o">&gt;</span> <span class="o">-</span><span class="mi">1</span> <span class="o">||</span>
	<span class="sr">/^Commons:Community_portal/</span><span class="p">.</span><span class="nx">test</span><span class="p">(</span><span class="nx">mw</span><span class="p">.</span><span class="nx">config</span><span class="p">.</span><span class="nx">get</span><span class="p">(</span><span class="s1">&#39;wgPageName&#39;</span><span class="p">)))</span> <span class="p">{</span>
	<span class="nx">mw</span><span class="p">.</span><span class="nx">loader</span><span class="p">.</span><span class="nx">load</span><span class="p">(</span><span class="s1">&#39;ext.gadget.WatchlistNotice.core&#39;</span><span class="p">);</span>
<span class="p">}</span>
</pre></div>
</div></div><noscript><img src="//commons.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript></div>
		<div class="printfooter">Retrieved from "<a dir="ltr" href="https://commons.wikimedia.org/w/index.php?title=MediaWiki:Gadget-WatchlistNotice.js&amp;oldid=97311724">https://commons.wikimedia.org/w/index.php?title=MediaWiki:Gadget-WatchlistNotice.js&amp;oldid=97311724</a>"</div>
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
		<div class="visualClear"></div>
		
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		<div id="p-personal" class="vector-menu" aria-labelledby="p-personal-label" 
	 >
	<h3 id="p-personal-label">
		<span>Personal tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="pt-uls" class="active"><a href="#" class="uls-trigger">English</a></li><li id="pt-anonuserpage">Not logged in</li><li id="pt-anontalk"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n">Talk</a></li><li id="pt-anoncontribs"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y">Contributions</a></li><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=MediaWiki%3AGadget-WatchlistNotice.js" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=MediaWiki%3AGadget-WatchlistNotice.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o">Log in</a></li></ul>
		
	</div>
</div>


		<div id="left-navigation">
			<div id="p-namespaces" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-namespaces-label" 
	 >
	<h3 id="p-namespaces-label">
		<span>Namespaces</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-nstab-mediawiki" class="selected"><a href="/wiki/MediaWiki:Gadget-WatchlistNotice.js" title="View the system message [c]" accesskey="c">Interface page</a></li><li id="ca-talk"><a href="/wiki/MediaWiki_talk:Gadget-WatchlistNotice.js" rel="discussion" title="Discussion about the content page [t]" accesskey="t">Discussion</a></li></ul>
		
	</div>
</div>


			<div id="p-variants" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-variants-label" 
	 >
	<input type="checkbox" class="vectorMenuCheckbox vector-menu-checkbox" aria-labelledby="p-variants-label" />
	<h3 id="p-variants-label">
		<span>Variants</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</div>


		</div>
		<div id="right-navigation">
			<div id="p-views" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-views-label" 
	 >
	<h3 id="p-views-label">
		<span>Views</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-view" class="collapsible selected"><a href="/wiki/MediaWiki:Gadget-WatchlistNotice.js">View</a></li><li id="ca-viewsource" class="collapsible"><a href="/w/index.php?title=MediaWiki:Gadget-WatchlistNotice.js&amp;action=edit" title="This page is protected.&#10;You can view its source [e]" accesskey="e">View source</a></li><li id="ca-history" class="collapsible"><a href="/w/index.php?title=MediaWiki:Gadget-WatchlistNotice.js&amp;action=history" title="Past revisions of this page [h]" accesskey="h">History</a></li></ul>
		
	</div>
</div>


			<div id="p-cactions" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-cactions-label" 
	 >
	<input type="checkbox" class="vectorMenuCheckbox vector-menu-checkbox" aria-labelledby="p-cactions-label" />
	<h3 id="p-cactions-label">
		<span>More</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</div>


			<div id="p-search" role="search">
	<h3 >
		<label for="searchInput">Search</label>
	</h3>
	<form action="/w/index.php" id="searchform">
		<div id="simpleSearch">
			<input type="search" name="search" placeholder="Search Wikimedia Commons" title="Search Wikimedia Commons [f]" accesskey="f" id="searchInput"/>
			<input type="hidden" name="title" value="Special:Search">
			<input type="submit" name="fulltext" value="Search" title="Search the pages for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/>
			<input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>
		</div>
	</form>
</div>

		</div>
	</div>
	
<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a  title="Visit the main page" class="mw-wiki-logo" href="/wiki/Main_Page"></a>
	</div>
	<div id="p-navigation" class="vector-menu vector-menu-portal portal portal-first" aria-labelledby="p-navigation-label" 
	 >
	<h3 id="p-navigation-label">
		<span>Navigate</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-mainpage-description"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z">Main page</a></li><li id="n-welcome"><a href="/wiki/Commons:Welcome">Welcome</a></li><li id="n-portal"><a href="/wiki/Commons:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li><li id="n-village-pump"><a href="/wiki/Commons:Village_pump">Village pump</a></li><li id="n-help"><a href="/wiki/Special:MyLanguage/Help:Contents" title="The place to find out">Help center</a></li></ul>
		
	</div>
</div>


	<div id="p-participate" class="vector-menu vector-menu-portal portal" aria-labelledby="p-participate-label" 
	 >
	<h3 id="p-participate-label">
		<span>Participate</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-uploadbtn"><a href="/wiki/Special:UploadWizard">Upload file</a></li><li id="n-recentchanges"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r">Recent changes</a></li><li id="n-latestfiles"><a href="/wiki/Special:NewFiles">Latest files</a></li><li id="n-randomimage"><a href="/wiki/Special:Random/File" title="Load a random file [x]" accesskey="x">Random file</a></li><li id="n-contact"><a href="/wiki/Commons:Contact_us">Contact us</a></li></ul>
		
	</div>
</div>

<div id="p-coll-print_export" class="vector-menu-empty emptyPortlet vector-menu vector-menu-portal portal" aria-labelledby="p-coll-print_export-label" 
	 >
	<h3 id="p-coll-print_export-label">
		<span>Print/export</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</div>

<div id="p-tb" class="vector-menu vector-menu-portal portal" aria-labelledby="p-tb-label" 
	 >
	<h3 id="p-tb-label">
		<span>Tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="t-whatlinkshere"><a href="/wiki/Special:WhatLinksHere/MediaWiki:Gadget-WatchlistNotice.js" title="A list of all wiki pages that link here [j]" accesskey="j">What links here</a></li><li id="t-recentchangeslinked"><a href="/wiki/Special:RecentChangesLinked/MediaWiki:Gadget-WatchlistNotice.js" rel="nofollow" title="Recent changes in pages linked from this page [k]" accesskey="k">Related changes</a></li><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-permalink"><a href="/w/index.php?title=MediaWiki:Gadget-WatchlistNotice.js&amp;oldid=97311724" title="Permanent link to this revision of the page">Permanent link</a></li><li id="t-info"><a href="/w/index.php?title=MediaWiki:Gadget-WatchlistNotice.js&amp;action=info" title="More information about this page">Page information</a></li></ul>
		
	</div>
</div>


</div>

</div>

<div id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-info" >
		<li id="footer-info-lastmod"> This page was last edited on 30 May 2013, at 17:40.</li>
		<li id="footer-info-copyright">Files are available under licenses specified on their description page. All structured data from the file and property namespaces is available under the <a href="https://creativecommons.org/publicdomain/zero/1.0/" title="Definition of the Creative Commons CC0 License">Creative Commons CC0 License</a>; all unstructured text is available under the <a href="https://creativecommons.org/licenses/by-sa/3.0/" title="Definition of the Creative Commons Attribution/Share-Alike License">Creative Commons Attribution-ShareAlike License</a>;
additional terms may apply.
By using this site, you agree to the <a href="//foundation.wikimedia.org/wiki/Terms_of_Use" title="Wikimedia Foundation Terms of Use">Terms of Use</a> and the <a href="//foundation.wikimedia.org/wiki/Privacy_policy" title="Wikimedia Foundation Privacy Policy">Privacy Policy</a>.</li>
	</ul>
	<ul id="footer-places" >
		<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy" class="extiw" title="wmf:Privacy policy">Privacy policy</a></li>
		<li id="footer-places-about"><a href="/wiki/Commons:Welcome" title="Commons:Welcome">About Wikimedia Commons</a></li>
		<li id="footer-places-disclaimer"><a href="/wiki/Commons:General_disclaimer" title="Commons:General disclaimer">Disclaimers</a></li>
		<li id="footer-places-developers"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li>
		<li id="footer-places-statslink"><a href="https://stats.wikimedia.org/#/commons.wikimedia.org">Statistics</a></li>
		<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
		<li id="footer-places-mobileview"><a href="//commons.m.wikimedia.org/w/index.php?title=MediaWiki:Gadget-WatchlistNotice.js&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
	</ul>
	<ul id="footer-icons" class="noprint">
		<li id="footer-copyrightico"><a href="https://wikimediafoundation.org/"><img src="/static/images/wikimedia-button.png" srcset="/static/images/wikimedia-button-1.5x.png 1.5x, /static/images/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation" loading="lazy" /></a></li>
		<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/static/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/poweredby_mediawiki_132x47.png 1.5x, /static/images/poweredby_mediawiki_176x62.png 2x" width="88" height="31"/></a></li>
	</ul>
	<div style="clear: both;"></div>
</div>


<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"limitreport":{"cputime":"0.004","walltime":"0.003","ppvisitednodes":{"value":1,"limit":1000000},"postexpandincludesize":{"value":0,"limit":2097152},"templateargumentsize":{"value":0,"limit":2097152},"expansiondepth":{"value":1,"limit":40},"expensivefunctioncount":{"value":0,"limit":500},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":0,"limit":5000000},"entityaccesscount":{"value":0,"limit":400},"timingprofile":["100.00%    0.000      1 -total"]},"cachereport":{"origin":"mw1331","timestamp":"20200609090251","ttl":2592000,"transientcontent":false}}});mw.config.set({"wgBackendResponseTime":124,"wgHostname":"mw1331"});});</script></body></html>
